mod provider;
pub use provider::*;

mod resolver;
pub use resolver::resolve_offset;
