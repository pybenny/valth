export { default as kReduxPersistLocalStorage } from "redux-persist/lib/storage";
